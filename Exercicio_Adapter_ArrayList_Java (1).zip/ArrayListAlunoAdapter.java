import java.util.ArrayList;

public class ArrayListAlunoAdapter implements RepositorioAluno {
    private ArrayList alunos;

    public ArrayListAlunoAdapter(ArrayList alunos) {
        this.alunos = alunos;
    }

    @Override
    public boolean cadastrar(Aluno aluno) {
        if (buscar(aluno.getMatricula()) != null) {
            return false;
        }

        return alunos.add(aluno);
    }

    @Override
    public Aluno buscar(String matricula) {
        for (int i = 0; i < alunos.size(); i++) {
            Aluno aluno = (Aluno) alunos.get(i);
            if (aluno.getMatricula().equals(matricula)) {
                return aluno;
            }
        }
        return null;
    }

    @Override
    public boolean excluir(String matricula) {
        Aluno aluno = buscar(matricula);
        return aluno != null && alunos.remove(aluno);
    }

    @Override
    public int quantidade() {
        return alunos.size();
    }

    @Override
    public void listar() {
        if (alunos.isEmpty()) {
            System.out.println("Nenhum aluno cadastrado.");
            return;
        }

        for (int i = 0; i < alunos.size(); i++) {
            Aluno aluno = (Aluno) alunos.get(i);
            System.out.println(aluno);
        }
    }
}
